const LoginRegister = document.querySelector('.LoginRegister');
const loginLink = document.querySelector('.login-link');
const registerLink = document.querySelector('.register-link');
const btnPop = document.querySelector('.btnLogin-pop');
const BackRe = document.querySelector('.icon-close');

const AjoutTopic = document.querySelector('.AjoutTopic');
const btnTopic = document.querySelector('.btnTopic-pop');
const RebtnTopicPop = document.querySelector('.icon-close2');
let d1 = document.getElementById("box");
let d2 = document.getElementById("box_log");


registerLink.addEventListener('click', ()=> { LoginRegister.classList.add('active');
    if(getComputedStyle(d2).display == "block"){
        d2.style.display = "none";
        } else {
        d2.style.display = "block";
        }
});

loginLink.addEventListener('click', ()=> { LoginRegister.classList.remove('active');
    if(getComputedStyle(d2).display == "block"){
        d2.style.display = "none";
        } else {
        d2.style.display = "block";
        }
});

btnPop.addEventListener('click', ()=> { LoginRegister.classList.add('active-popup');
    if(getComputedStyle(d1).display == "none"){
        d1.style.display = "block";
        } else {
        d1.style.display = "none";
        }
});

BackRe.addEventListener('click', ()=> { LoginRegister.classList.remove('active-popup');
    if(getComputedStyle(d1).display == "none"){
        d1.style.display = "block";
        } else {
        d1.style.display = "none";
        }
});

btnTopic.onclick = () => { 
    AjoutTopic.classList.add('active-topic');
};

RebtnTopicPop.onclick = () => { 
    AjoutTopic.classList.remove('active-topic');
};
