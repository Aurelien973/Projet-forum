<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="<?php echo e(asset('css/utilisateur.css')); ?>">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="<?php echo e(asset ('image/background.jpg')); ?>">
    <title>Forum</title>
</head>
<body>

    <header>
        <h1 class="nom-forum">Talk To Much</h1>
        <h2 class="image" src="<?php echo e(asset ('image/talk.jpg')); ?>"></h2>
            <h3 class="image2" src="<?php echo e(asset('image/background.jpg')); ?>"></h3>
            <nav class="menu-nav">
                <button class="btnTopic-pop">Topic</button>
                <button class="btnLogin-pop">Login</button>
            </nav>   

    </header>

        <!-- Menu Login --> 
    <div class="LoginRegister">
        <span class="icon-close">
            <i class='bx bxs-x-circle'></i>
        </span>
        <div class="Login">
            <div class="box-login">
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>
                <form action="<?php echo e(route('Login.post')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <h1>Login</h1>
                    <div class="input-box">
                        <input type="text" placeholder="Username" name="username"
                        required>
                        <span class="icon">
                        <i class='bx bxs-user-circle'></i>
                        </span>
                    </div>
                    <div class="input-box">
                        <input type="password" placeholder="Password" name="password" required>
                        
                        <span class="icon">
                        <i class='bx bxs-lock-alt' ></i>
                        </span>
                    </div>

                    <div class="remember_forgot">
                        <label><input type="checkbox">Remember me</label>
                        <a href="#">Forgot password ?</a>
                </div>

                 <button type="submit" class="btn">Login</button>

                    <div class="login-register">
                    <p>Je n'ai pas de compte<a
                    href="#" class="register-link">Register</a></p>
                    </div>
                </form>
            </div>
        </div>

        <div class="Register">
            <div class="box-register">
                <form action="<?php echo e(route('Creation.post')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <h1>Register</h1>
                    <div class="input-box">
                        <input type="text" placeholder="Username" name='username'
                        required>
                        <span class="icon">
                        <i class='bx bxs-user-circle'></i>
                        </span>
                    </div>
                    <div class="input-box">
                        <input type="text" placeholder="E-mail" name='email'
                        required>
                        <span class="icon">
                        <i class='bx bxl-gmail'></i>
                        </span>
                    </div>
                    <div class="input-box">
                        <input type="password" placeholder="Password" name='password' required>
                        
                        <span class="icon">
                        <i class='bx bxs-lock-alt' ></i>
                        </span>
                    </div>

                    <div class="remember_forgot">
                        <label><input type="checkbox">I agree to the term & condition</label>
                </div>

                 <button type="submit" class="btn">Register</button>

                    <div class="login-register">
                    <p>J'ai déja un compte<a
                    href="#" class="login-link">Login</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>  

        <div class="AjoutTopic">
            <span class="icon-close2">
                <i class='bx bxs-x-circle'></i>
            </span>
            <form action="" method="post">
                <div class="Message">
                <label for="message">TOPIC</label>
                </div>
                <div class="Case-msg">
                <input name="message" id="message" placeholder="Entrez vôtre sujet avec #" required #></input>
                </div>
                    <button type="submit">Add</button>
               
            </form>
        </div> 
            <div class="Categorie">
                <span class="icon-menu">
                    <i class='bx bx-menu'></i>
                </span>
            <form action="" method="post">
                

                </form>
            </div>

    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
    <!--<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>-->
</body>
</html><?php /**PATH C:\Users\logan\Forum_Projet\resources\views/utilisateur_view.blade.php ENDPATH**/ ?>