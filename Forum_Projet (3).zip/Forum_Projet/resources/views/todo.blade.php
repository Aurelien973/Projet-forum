<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <link rel="stylesheet" href="{{ asset('css/utilisateur.css') }}">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="{{ asset ('image/background.jpg') }}">
    
    <title>Forum</title>
</head>
<body>
<header>
        <h1 class="nom-forum">Talk To Much</h1>

        <form class="row g-3 justify-content-center" method="POST" action="{{route('todos.store')}}">
        @csrf
        <div class="col-6">
            <input type="text" class="form-control" name="title" placeholder="Creer un Topic">
        </div>
        <div class="col-auto">
            <button type="submit" class="btn btn-primary mb-3">Submit</button>
        </div>
        </form>
        </div>

        <h2 class="image" src="{{ asset ('image/talk.jpg') }}"></h2>
            <h3 class="image2" src="{{ asset('image/background.jpg') }}"></h3>
            <nav class="menu-nav">
                <button class="btnTopic-pop">Topic</button>
                <button class="btnLogin-pop">Login</button>
            </nav>   
            <div class="text-center mt-5">


</header>

        <!-- Menu Login --> 
    <div class="LoginRegister">
        <span class="icon-close">
            <i class='bx bxs-x-circle'></i>
        </span>
        <div class="Login">
            <div class="box-login">
                @if (session('success'))
                    <div class="alert alert-success">
                        {{ session('success') }}
                    </div>
                @endif
                <form action="{{route('Login.post')}}" method="POST">
                    @csrf
                    <h1>Login</h1>
                    <div class="input-box">
                        <input type="text" placeholder="Username" name="username"
                        required>
                        <span class="icon">
                        <i class='bx bxs-user-circle'></i>
                        </span>
                    </div>
                    <div class="input-box">
                        <input type="password" placeholder="Password" name="password" required>
                        
                        <span class="icon">
                        <i class='bx bxs-lock-alt' ></i>
                        </span>
                    </div>

                    <div class="remember_forgot">
                        <label><input type="checkbox">Remember me</label>
                        <a href="#">Forgot password ?</a>
                </div>

                 <button type="submit" class="btn">Login</button>

                    <div class="login-register">
                    <p>Je n'ai pas de compte<a
                    href="#" class="register-link">Register</a></p>
                    </div>
                </form>
            </div>
        </div>

        <div class="Register">
            <div class="box-register">
                <form action="{{route('Creation.post')}}" method="POST">
                    @csrf
                    <h1>Register</h1>
                    <div class="input-box">
                        <input type="text" placeholder="Username" name='username'
                        required>
                        <span class="icon">
                        <i class='bx bxs-user-circle'></i>
                        </span>
                    </div>
                    <div class="input-box">
                        <input type="text" placeholder="E-mail" name='email'
                        required>
                        <span class="icon">
                        <i class='bx bxl-gmail'></i>
                        </span>
                    </div>
                    <div class="input-box">
                        <input type="password" placeholder="Password" name='password' required>
                        
                        <span class="icon">
                        <i class='bx bxs-lock-alt' ></i>
                        </span>
                    </div>

                    <div class="remember_forgot">
                        <label><input type="checkbox">I agree to the term & condition</label>
                </div>

                 <button type="submit" class="btn">Register</button>

                    <div class="login-register">
                    <p>J'ai déja un compte<a
                    href="#" class="login-link">Login</a></p>
                    </div>
                </form>
            </div>
        </div>
    </div>  

    <script src="{{ asset('js/script.js') }}"></script>
    <!--<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js"></script>
    <script nomodule src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script>-->



<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>



<div class="row justify-content-center mt-5">
    <div class="col-lg-6">
        @if(session()->has('success'))
            <div class="alert alert-success">
                {{ session()->get('success') }}
            </div>
        @endif

        @if ($errors->any())
            @foreach ($errors->all() as $error)
                <div class="alert alert-danger">
                    {{$error}}
                </div>
            @endforeach
        @endif
    </div>
</div>

<div class="text-center">
    <h2>LISTE TOPIC</h2>
    <div class="row justify-content-center">
        <div class="col-lg-6">

            <table class="table table-bordered">
                <thead>
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Nom</th>
                    <th scope="col">Date de creation</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                </tr>
                </thead>
                <tbody>

                @php $counter=1 @endphp

                @foreach($todos as $todo)
                    <tr>
                        <th>{{$counter}}</th>
                        <td>{{$todo->title}}</td>
                        <td>{{$todo->created_at}}</td>
                        <td>
                            @if($todo->is_completed)
                                <div class="badge bg-success">Résolu</div>
                            @else
                                <div class="badge bg-warning">Non résolu</div>
                            @endif
                        </td>
                        <td>
                            <a href="{{route('todos.edit',['todo'=>$todo->id])}}" class="btn btn-info">Edit</a>
                            <a href="{{route('todos.destory',['todo'=>$todo->id])}}" class="btn btn-danger">Delete</a>
                        </td>
                    </tr>

                    @php $counter++; @endphp

                @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>

</body>
</html>