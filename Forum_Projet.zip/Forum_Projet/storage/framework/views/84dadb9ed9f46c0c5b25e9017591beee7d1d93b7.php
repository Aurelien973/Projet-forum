<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Talk to Much</title>
    <link rel="stylesheet" href=".../css/style.css">
</head>
<body>
    <div class="contenu">
        <div class="sous-forum">
            <div class=" sous-forum_titre ">
                <h1> Talk To Much</h1>
            </div>
            <div class=" sous-forum_home">
                <div class="home-icon">
                    <i class="fa fa-car"&></i>
                     <div id="main">
                
                        <div id="menu">
                        <ul>
                            <li><a href="acc.html" strong >Accueil</a></li> 
                            <li><a href="prof.html"target="_blank">Login</a></li>
                  
                        </ul>
                        </div>
                    <div class="row">
                        <input type="text" id="input-box" placeholder="Add your topic">
                        <button>Ajouter</button>
                    </div>
                </div>
            </div>
            

            </div>
        </div>
    </div>
    <script src="main.js"></script>
</body>
</html><?php /**PATH C:\Users\logan\Forum_Projet\resources\views/todo.blade.php ENDPATH**/ ?>